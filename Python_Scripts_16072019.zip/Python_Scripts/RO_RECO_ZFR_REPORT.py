# Importing required modules 
import os		# Use for system Path location
import numpy as np		# Use for Numpy module for number	
import pandas as pd		# Use for Pandas module
from pandas import ExcelFile		# Use for Excel
from pandas import ExcelWriter		# Use for Read Excel
import time			# Use for Pandas method

path="D:\\SHYAMA_WORKING\\ZFR_REPORT\\Python_Report" 	# Current working path
os.chdir(path)  # Set Current working path
os.getcwd()       # Prints the current working directory

# Read Excel file
zfr6011=pd.read_excel('ZFR_REPORT_P92_6011.xlsx',0)
zfr6000=pd.read_excel('ZFR_REPORT_P91_6000.xlsx',0)

# Arranging columns
zfr1=zfr6011[['Circle','Site Id','Company code','Lease Req.No','Contract Type','Vendor No.','Vendor Name','Company Code','Business Entity Numb','Contract No.','Bus. Area','Location','Address']]
zfr2=zfr6000[['Circle','Site Id','Company code','Lease Req.No','Contract Type','Vendor No.','Vendor Name','Company Code','Business Entity Numb','Contract No.','Bus. Area','Location','Address']]

# Concatenating the dataframes
zfr=pd.concat([zfr1,zfr2])

# Multiple if else conditions in pandas dataframe and derive multiple columns based on column
def Bus_Area(x):
	if (x['Bus. Area'] == 'KOA1'):
		return 'CHANDAN NAGAR'
	elif (x['Bus. Area'] == 'KOA2'):
		return "SERAMPORE"
	elif (x['Bus. Area'] == 'KOA3'):
		return 'BARRACKPORE'
	elif (x['Bus. Area'] == 'KOA4'):
		return 'DUNLOP'
	elif (x['Bus. Area'] == 'KOA5'):
		return 'BARASAT'
	elif (x['Bus. Area'] == 'KOA6'):
		return 'RAJARHAT'
	elif (x['Bus. Area'] == 'KOA7'):
		return 'HOWRAH'
	elif (x['Bus. Area'] == 'KOA8'):
		return 'CENTRAL AVENUE'
	elif (x['Bus. Area'] == 'KOA9'):
		return 'ALIPORE'
	elif (x['Bus. Area'] == 'KOB0'):
		return 'PARKSTREET'
	elif (x['Bus. Area'] == 'KOB1'):
		return 'KASBA'
	elif (x['Bus. Area'] == 'KOB2'):
		return 'JAMES LONG SARANI'
	elif (x['Bus. Area'] == 'KOB3'):
		return 'KAMALGAZI'
	elif (x['Bus. Area'] == 'KOB4'):
		return 'NAIHATI'
	
zfr = zfr.assign(JC_Name=zfr.apply(Bus_Area, axis=1))

# Change the order of columns
zfr=zfr[['Circle','Site Id','Company code','Lease Req.No','Contract Type','Vendor No.','Vendor Name','Company Code','Business Entity Numb','Contract No.','Bus. Area','JC_Name','Location','Address']]

# Read Excel file
znt91=pd.read_excel('ZNETWORKEXP_P91.xlsx',0)
znt92=pd.read_excel('ZNETWORKEXP_P92.xlsx',0)

# Concatenating the dataframes
znetwk=pd.concat([znt91,znt92],ignore_index=True)

z=pd.merge(left=zfr,right=znetwk, how='left', left_on=['Site Id'], right_on=['Site id']).drop(columns=['Company Code_y','Site id','Site type','Site status']).rename(columns={'REObject':'Znetwork_RO'})

# Mutiple Filter where 'Business Entity Numb' notnull and 'Znetwork_RO' isnull
z1=z[(z['Business Entity Numb'].notnull())&z['Znetwork_RO'].isnull()]

# Use for current datetime format
datetime = time.strftime("%Y%m%d_%H%M")		
		   
# ExportFileName
ExportFileName='RO_Not_in_ZNETWORKEXP_'+ datetime +'.xlsx'	

# Create a Pandas Excel writer using XlsxWriter as the engine.
writer = pd.ExcelWriter(ExportFileName, engine='xlsxwriter')

# Write each dataframe to a different worksheet.
z1.to_excel(writer, sheet_name='Details',index=False)

# Close the Pandas Excel writer and output the Excel file.
writer.save()
